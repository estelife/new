<?php
$MESS ['ESTELIFE_HEAD_TITLE'] = 'Список типов услуг';
$MESS ['ESTELIFE_F_TITLE'] = 'Название';
$MESS ['ESTELIFE_F_ID'] = 'ID';
$MESS ['ESTELIFE_F_SPEC'] = 'Специализация';
$MESS ['ESTELIFE_F_SERVICE'] = 'Тип услуги';
$MESS ['ESTELIFE_F_METHOD'] = 'Методика';
$MESS ['ESTELIFE_CREATE'] = 'Создать тип услуги';
$MESS ['ESTELIFE_CREATE_TITLE'] = 'Отобразиться форма для создания типа услуги';
$MESS ['ESTELIFE_NOT_IMPORTANT'] = 'Не важно';

$MESS ['ESTELIFE_EDIT_ALT']='Редактирование';
$MESS ['ESTELIFE_DELETE_ALT']='Удаление';
$MESS ['ESTELIFE_CONFIRM_DELETE']='Вы дейсвтительно хотите удалить эту запись и связанные с ней данные?';
$MESS ['ESTELIFE_EDIT']='Изменить';
$MESS ['ESTELIFE_DELETE']='Удалить';