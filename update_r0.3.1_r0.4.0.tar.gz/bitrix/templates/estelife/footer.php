	</div>
	<div class="footer">
		<div class="footer-in">
			<div class="content">
				<ul class="menu cols">
					<li><a href="#">О проекте</a></li>
					<li><a href="#">Связь с редакцией</a></li>
					<li><a href="#">Размещение рекламы</a></li>
					<li><a href="#">Защита контента</a></li>
				</ul>
				<div class="cols col2 social">
					<a href="http://vk.com/estelife_ru" class="vk">ВКонтакте</a>
					<a href="https://www.facebook.com/EsteLife.RU" class="fb">Facebook</a>
					<a href="http://www.youtube.com/esteliferu" class="yt">Youtube</a>
					<a href="https://plus.google.com/u/0/b/106608290098923557575/" class="gp">Google+</a>
				</div>
				<div class="copy">
					2011-2013 &copy; ООО &laquo;Эстелайф&raquo;. Estelife.ru. Портал эстетической медицины
					<span><b>18</b>+</span>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>
