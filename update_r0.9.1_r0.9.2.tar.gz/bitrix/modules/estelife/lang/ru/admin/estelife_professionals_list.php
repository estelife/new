<?php
$MESS ['ESTELIFE_F_ID']='ID';
$MESS ['ESTELIFE_F_USER_ID']='Пользователь';
$MESS ['ESTELIFE_F_COUNTRY']='Страна';
$MESS ['ESTELIFE_F_CITY']='Город';
$MESS ['ESTELIFE_F_DESCRIPTION']='Описание';
$MESS ['ESTELIFE_CREATE']='Добавить специалиста';
$MESS ['ESTELIFE_EDIT_ALT']='Изменить';
$MESS ['ESTELIFE_EDIT']='Изменить';
$MESS ['ESTELIFE_DELETE_ALT']='Удалить';
$MESS ['ESTELIFE_DELETE']='Удалить';
$MESS ['ESTELIFE_CONFIRM_DELETE']='Вы действительно хотите удалить этого специалиста?';
$MESS ['ESTELIFE_HEAD_TITLE']='Специалисты';
$MESS ['ESTELIFE_F_CLINIC']='Клиника';
$MESS ['ESTELIFE_F_ACTIVITY']='Событие';
