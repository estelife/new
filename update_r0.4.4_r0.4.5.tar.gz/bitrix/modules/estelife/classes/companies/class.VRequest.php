<?php
namespace companies;

/**
 * Вероятно я забыл оставить описание файла. Обратитесь на мыло за уточнениями.
 * @author Dmitriy Konev <dnkonev@yandex.ru>
 * @since 17.01.14
 */
class VRequest {
	private $sName;
	private $sEmail;
	private $sPhone;

	public function __construct($sName,$sEmail,$sPhone){

	}

	public function create($nCompanyId,$nType){

	}

	public function check($nCompanyId,$nType){

	}
}