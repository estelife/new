<?
$PERM["tmp"]["5"]="W";
$PERM["admin"]["*"]="D";
?>