<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)
	die();

bitrix\ERESULT::$DATA['PTYPE']=3;
require_once __DIR__.'/preparations_filter.php';