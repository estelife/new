<?
$MESS ['IBLOCK_NEWS_NAME'] = "News";
$MESS ['IBLOCK_NEWS_DESCRIPTION'] = "News section";
$MESS ['T_IBLOCK_DESC_NEWS'] = "News";
?>
