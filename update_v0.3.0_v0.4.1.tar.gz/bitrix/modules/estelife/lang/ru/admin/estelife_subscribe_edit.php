<?php
$MESS ['ESTELIFE_T_BASE'] = 'Основное';
$MESS ['ESTELIFE_CREATE_TITLE'] = 'Изменение подписки';
$MESS ['ESTELIFE_F_EMAIL'] = 'Email';
$MESS ['ESTELIFE_F_ACTIVE'] = 'Активность';
$MESS ['ESTELIFE_F_TYPE_SELECT'] = 'Тип';
$MESS ['ESTELIFE_F_DATE_SEND'] = 'Дата отправки';