<?php
$MESS ['ESTELIFE_MENU_MAIN'] = "Estelife";
$MESS ['ESTELIFE_MENU_MAIN_TITLE'] = "Независимый модуль портала Estelife";
$MESS ['ESTELIFE_SERVICE_REFERENCE'] ='Справочник услуг';
$MESS ['ESTELIFE_SERVICE_REFERENCE_TITLE'] ='В данном справочнике приведены специализации, виды процедур, типы процедур';
$MESS ['ESTELIFE_SPECIALIZATION'] = 'Специализации';
$MESS ['ESTELIFE_SPECIALIZATION_TITLE'] = 'Управление специализациями';
$MESS ['ESTELIFE_SERVICE'] = 'Виды услуг';
$MESS ['ESTELIFE_SERVICE_TITLE'] = 'Управление типами услуг';
$MESS ['ESTELIFE_SERVICE_CONCREATE'] = 'Типы услуг';
$MESS ['ESTELIFE_SERVICE_CONCREATE_TITLE'] ='Управление видами услуг';
$MESS ['ESTELIFE_CLINICS']='Клиники и Акции';
$MESS ['ESTELIFE_CLINICS_TITLE'] = 'Управление клиниками и акциями';
$MESS ['ESTELIFE_CLINIC_LIST'] = 'Клиники';
$MESS ['ESTELIFE_CLINIC_LIST_TITLE'] = 'Управление клиниками';
$MESS ['ESTELIFE_AKZII']='Акции';
$MESS ['ESTELIFE_AKZII_TITLE']='Управление акциями';
$MESS ['ESTELIFE_EVENTS']='События';
$MESS ['ESTELIFE_EVENTS_TITLE']='Управление мероприятиями и обучением';
$MESS ['ESTELIFE_TRAINING']='Обучения';
$MESS ['ESTELIFE_TRAINING_TITLE']='Управление обучениями';
$MESS ['ESTELIFE_ACTIVITY']='Мероприятия';
$MESS ['ESTELIFE_ACTIVITY_TITLE']='Управление мероприятиями';
$MESS ['ESTELIFE_COMPANIES']='Компании';
$MESS ['ESTELIFE_COMPANIES_LIST']='Компании';
$MESS ['ESTELIFE_COMPANIES_TITLE']='Управление компаниями';
$MESS ['ESTELIFE_PRODUCTION']='Продукция';
$MESS ['ESTELIFE_PILLS']='Препараты';
$MESS ['ESTELIFE_APPARATUS']='Аппараты';
$MESS ['ESTELIFE_PRODUCTION_TITLE']='Управление продукцией';
$MESS ['ESTELIFE_PILLS_TITLE']='Управление препаратами';
$MESS ['ESTELIFE_APPARATUS_TITLE']='Управление аппаратами';
$MESS ['ESTELIFE_METHODS']='Методики';
$MESS ['ESTELIFE_METHODS_TITLE']='Управление методиками';

$MESS ['ESTELIFE_SPECIAL']='Специальные разделы';
$MESS ['ESTELIFE_SUBSCRIBE_TITLE']='Управление подпиской';
$MESS ['ESTELIFE_SUBSCRIBE_LIST']='Список подписок';
$MESS ['ESTELIFE_REQUEST_TITLE']='Управление заявками';
$MESS ['ESTELIFE_REQUEST_LIST']='Список заявок';
$MESS ['ESTELIFE_COMMENTS']='Комментарии';
$MESS ['ESTELIFE_COMMENTS_TITLE']='Управление комментариями';
$MESS ['ESTELIFE_COMMENTS_LIST']='Список комментариев';
$MESS ['ESTELIFE_THREADS']='Нити';
$MESS ['ESTELIFE_THREADS_TITLE']='Управление нитями';
$MESS ['ESTELIFE_THREADS_LIST']='Список нитей';
$MESS ['ESTELIFE_IMPLANTS']='Имплантаты';
$MESS ['ESTELIFE_IMPLANTS_TITLE']='Управление имплантатами';
$MESS ['ESTELIFE_IMPLANTS_LIST']='Список имплантатов';



