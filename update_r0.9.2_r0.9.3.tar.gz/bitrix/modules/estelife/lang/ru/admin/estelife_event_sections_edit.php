<?php
$MESS ['ESTELIFE_T_BASE']='Основное';
$MESS ['ESTELIFE_T_CALENDAR']='Даты, время, залы';
$MESS ['ESTELIFE_F_NAME']='Название';
$MESS ['ESTELIFE_CREATE_TITLE']='Редактирование секции';
$MESS ['ESTELIFE_F_EVENT']='Мероприятие';
$MESS ['ESTELIFE_F_HALLS']='Залы';
$MESS ['ESTELIFE_F_THEME']='Тема';
$MESS ['NAME_NOT_FILL'] = 'Не указано название';
$MESS ['EVENT_NOT_FILL']='Не выбрано мероприятие';
$MESS ['HALL_NOT_FILL'] = 'Не указано ни одного зала';
$MESS ['ERROR_FIELD_FILL'] ='Ошибка заполнения поля';