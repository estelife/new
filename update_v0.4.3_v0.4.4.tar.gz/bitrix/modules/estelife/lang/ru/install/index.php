<?php
$MESS ['ESTELIFE_PRIVATE'] = 'Доступ к закрытым частям';