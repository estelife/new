<? $MESS ['ESTELIFE_F_ID'] = 'ID';
   $MESS ['ESTELIFE_F_NAME'] = 'Название';
   $MESS ['ESTELIFE_CREATE'] = 'Добавить тип';
   $MESS ['ESTELIFE_CREATE_TITLE'] = 'Добавить тип';
   $MESS ['ESTELIFE_EDIT_ALT'] = 'Изменить';
   $MESS ['ESTELIFE_EDIT'] = 'Изменить';
   $MESS ['ESTELIFE_DELETE'] = 'Удалить';
   $MESS ['ESTELIFE_DELETE_ALT'] = 'Удалить';
   $MESS ['ESTELIFE_CONFIRM_DELETE'] = 'Вы действительно хотите удалить эту запись?';
   $MESS ['ESTELIFE_HEAD_TITLE']='Типы событий';


