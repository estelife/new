<?php
$MESS ['ESTELIFE_F_ID']='ID';
$MESS ['ESTELIFE_F_NAME']='Название';
$MESS ['ESTELIFE_F_EVENT_NAME']='Мероприятие';
$MESS ['ESTELIFE_EDIT_ALT']='Изменить';
$MESS ['ESTELIFE_EDIT']='Изменить';
$MESS ['ESTELIFE_DELETE_ALT']='Удалить';
$MESS ['ESTELIFE_DELETE']='Удалить';
$MESS ['ESTELIFE_CONFIRM_DELETE']='Вы действительно хотите удалить этот зал?';
$MESS ['ESTELIFE_F_EVENT']='Мероприятие';
$MESS ['ESTELIFE_CREATE']='Добавить зал';
$MESS ['ESTELIFE_CREATE_ALT']='Добавить зал';
$MESS ['ESTELIFE_HEAD_TITLE']='Залы';


