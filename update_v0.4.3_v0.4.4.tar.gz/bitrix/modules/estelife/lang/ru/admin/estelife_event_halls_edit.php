<?php
$MESS ['ESTELIFE_F_NAME']='Название';
$MESS ['ESTELIFE_F_EVENT']='Мероприятие';
$MESS ['ESTELIFE_T_BASE']='Основное';
$MESS ['ESTELIFE_F_TRANSLIT']='Транслит';
$MESS ['ESTELIFE_CREATE_TITLE']='Редактирование зала';
$MESS ['ERROR_FIELD_FILL'] ='Ошибка заполнения поля';