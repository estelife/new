<?php
$MESS ['ESTELIFE_T_BASE'] = "Основное";
$MESS ['ESTELIFE_F_NAME'] = "Имя";
$MESS ['ESTELIFE_F_EMAIL'] = "Email";
$MESS ['ESTELIFE_F_PHONE'] = "Телефон";