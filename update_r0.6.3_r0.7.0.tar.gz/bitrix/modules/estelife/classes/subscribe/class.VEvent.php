<?php
/**
 *
 * @author Maxim Shlemarev <shlemarev@gmail.com>
 * @since 30.01.14
 */

class VEvent {

	public function __construct($arData){


	}



}