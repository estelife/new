<?php
$MESS ['ESTELIFE_HEAD_TITLE'] = 'Список типов аппаратов';
$MESS ['ESTELIFE_F_TITLE'] = 'Название';
$MESS ['ESTELIFE_F_ID'] = 'ID';
$MESS ['ESTELIFE_F_TYPE'] = 'Тип аппарата';
$MESS ['ESTELIFE_CREATE'] = 'Добавить тип';

$MESS ['ESTELIFE_EDIT_ALT']='Редактирование';
$MESS ['ESTELIFE_DELETE_ALT']='Удаление';
$MESS ['ESTELIFE_CONFIRM_DELETE']='Вы дейсвтительно хотите удалить эту запись и связанные с ней данные?';
$MESS ['ESTELIFE_EDIT']='Изменить';
$MESS ['ESTELIFE_DELETE']='Удалить';