<?php if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();?>
<div class="cols col1">
	<b>Ваш город:</b>
	<a href="#" class="arrow gray bottom change_main_city change_city">
		<span class="city_<?=$arResult['city']['ID']?>"><?=$arResult['city']['NAME']?></span>
	</a>
</div>
