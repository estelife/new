<?php
$MESS ['ESTELIFE_HEAD_TITLE'] = 'Список имплантатов';
$MESS ['ESTELIFE_F_TITLE'] = 'Название';
$MESS ['ESTELIFE_F_ID'] = 'ID';
$MESS ['ESTELIFE_F_COMPANY'] = 'Компания';
$MESS ['ESTELIFE_CREATE'] = 'Добавить имплантат';

$MESS ['ESTELIFE_EDIT_ALT']='Редактирование';
$MESS ['ESTELIFE_DELETE_ALT']='Удаление';
$MESS ['ESTELIFE_CONFIRM_DELETE']='Вы дейсвтительно хотите удалить эту запись и связанные с ней данные?';
$MESS ['ESTELIFE_EDIT']='Изменить';
$MESS ['ESTELIFE_DELETE']='Удалить';