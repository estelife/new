<?
$MESS ['NEWS_BACK_TEXT'] = "Back to list";
?>