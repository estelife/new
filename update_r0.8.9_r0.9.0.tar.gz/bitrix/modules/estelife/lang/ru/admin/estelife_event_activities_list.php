<?php
$MESS ['ESTELIFE_F_TITLE']='Название';
$MESS ['ESTELIFE_F_SHORT_DESCRIPTION']='Описание';
$MESS ['ESTELIFE_F_WITH_VIDEO']='Видео';
$MESS ['ESTELIFE_F_FROM_TIME']='Начало';
$MESS ['ESTELIFE_F_TO_TIME']='Окончание';
$MESS ['ESTELIFE_F_DURATION']='Продолжительность';
$MESS ['ESTELIFE_F_TYPE']='Тип';
$MESS ['ESTELIFE_F_HALL']='Зал';
$MESS ['ESTELIFE_F_SECTION']='Секция';
$MESS ['ESTELIFE_CREATE']='Добавить событие';
$MESS ['ESTELIFE_EDIT_ALT']='Изменить';
$MESS ['ESTELIFE_EDIT']='Изменить';
$MESS ['ESTELIFE_DELETE_ALT']='Удалить';
$MESS ['ESTELIFE_DELETE']='Удалить';
$MESS ['ESTELIFE_CONFIRM_DELETE']='Вы действительно хотите удалить это событие?';
$MESS ['ESTELIFE_HEAD_TITLE']='Список событий';
$MESS ['ESTELIFE_F_EVENT']='Мероприятие';
