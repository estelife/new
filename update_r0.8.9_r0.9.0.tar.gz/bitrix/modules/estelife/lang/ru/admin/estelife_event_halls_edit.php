<?php
$MESS ['ESTELIFE_F_NAME']='Название';
$MESS ['ESTELIFE_F_EVENT']='Мероприятие';
$MESS ['ESTELIFE_T_BASE']='Основное';
$MESS ['ESTELIFE_CREATE_TITLE']='Редактирование зала';
