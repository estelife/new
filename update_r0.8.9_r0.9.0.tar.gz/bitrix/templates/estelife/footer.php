		</div>
		<div class="cl">
	</div><!--wrap-fix!-->
	<div class="footer">
		<div class="footer-in">
			<div class="content">
<!--				<ul class="menu cols">-->
<!--					<li><a href="#">О проекте</a></li>-->
<!--					<li><a href="#">Связь с редакцией</a></li>-->
<!--					<li><a href="#">Размещение рекламы</a></li>-->
<!--					<li><a href="#">Защита контента</a></li>-->
<!--				</ul>-->
				<div class="copy">
					2011-2013 &copy; ООО &laquo;Эстелайф&raquo;. Estelife.ru. Портал эстетической медицины
					<span><b>18</b>+</span>
					<div class="cols col2 social">
						<a href="http://vk.com/estelife_ru" class="vk" target="_blank">ВКонтакте</a>
						<a href="https://www.facebook.com/EsteLife.RU" class="fb" target="_blank">Facebook</a>
						<a href="http://www.youtube.com/esteliferu" class="yt" target="_blank">Youtube</a>
						<a href="https://plus.google.com/u/0/b/106608290098923557575/" class="gp" target="_blank">Google+</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<a href="#" class="to-top"><i></i>Вверх</a>
	<?$APPLICATION->IncludeComponent("estelife:notice.all","",array())?>
</div>
<!--		<img src="/el.png" class="home-img" />-->
<!-- Yandex.Metrika counter --><script type="text/javascript">(function (d, w, c) { (w[c] = w[c] || []).push(function() { try { w.yaCounter21339871 = new Ya.Metrika({id:21339871, webvisor:true, clickmap:true, trackLinks:true, accurateTrackBounce:true, trackHash:true}); } catch(e) { } }); var n = d.getElementsByTagName("script")[0], s = d.createElement("script"), f = function () { n.parentNode.insertBefore(s, n); }; s.type = "text/javascript"; s.async = true; s.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//mc.yandex.ru/metrika/watch.js"; if (w.opera == "[object Opera]") { d.addEventListener("DOMContentLoaded", f, false); } else { f(); } })(document, window, "yandex_metrika_callbacks");</script><noscript><div><img src="//mc.yandex.ru/watch/21339871" style="position:absolute; left:-9999px;" alt="" /></div></noscript><!-- /Yandex.Metrika counter -->
<!-- Rating@Mail.ru counter -->
<script type="text/javascript">//<![CDATA[
	var _tmr = _tmr || [];
	_tmr.push({id: "2435150", type: "pageView", start: (new Date()).getTime()});
	(function (d, w) {
		var ts = d.createElement("script"); ts.type = "text/javascript"; ts.async = true;
		ts.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//top-fwz1.mail.ru/js/code.js";
		var f = function () {var s = d.getElementsByTagName("script")[0]; s.parentNode.insertBefore(ts, s);};
		if (w.opera == "[object Opera]") { d.addEventListener("DOMContentLoaded", f, false); } else { f(); }
	})(document, window);
	//]]></script><noscript><div style="position:absolute;left:-10000px;">
		<img src="//top-fwz1.mail.ru/counter?id=2435150;js=na" style="border:0;" height="1" width="1" alt="Рейтинг@Mail.ru" />
	</div></noscript>
<!-- //Rating@Mail.ru counter -->

</body>
</html>
