<?php
$MESS["ESTELIFE_CLINIC_FILTER"] = "Фильтр";
$MESS["ESTELIFE_COUNTRY"] = "Страна";
$MESS["ESTELIFE_TYPE"] = "Тип аппарата";
$MESS["ESTELIFE_NAME"] = "Название";
?>