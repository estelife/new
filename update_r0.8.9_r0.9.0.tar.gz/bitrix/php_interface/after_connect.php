<?php
$DB->Query("SET NAMES 'utf8'");
$DB->Query('SET collation_connection = "utf8_unicode_ci"');
CPageOption::SetOptionString('main','nav_page_in_session','N');