<?
$MESS ['NEWS_BACK_TEXT'] = "Возврат к списку";
?>