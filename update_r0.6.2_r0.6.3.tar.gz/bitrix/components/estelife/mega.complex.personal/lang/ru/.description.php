<?
$MESS ['IBLOCK_NEWS_NAME'] = "Новости";
$MESS ['IBLOCK_NEWS_DESCRIPTION'] = "Новостной раздел";
$MESS ['T_IBLOCK_DESC_NEWS'] = "Новости";
?>