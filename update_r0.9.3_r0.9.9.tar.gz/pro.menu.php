<?php
$aMenuLinks = Array(
	Array(
		"Ботулотоксины", 
		"/pro/botulinotherapy/articles/", 
		Array(), 
		Array("INFO"=>"80 материалов"), 
		"" 
	),
	Array(
		"Мезотерапия",
		"/pro/mesotherapy/articles/",
		Array(),
		Array("INFO"=>"55 материалов"),
		""
	),
	Array(
		"Фототерапия",
		"/pro/phototherapie/articles/",
		Array(),
		Array("INFO"=>"37 материалов"),
		""
	),
	Array(
		"RF-Лифтинг",
		"/pro/rf-lifting/articles/",
		Array(),
		Array("INFO"=>"50 материалов"),
		""
	),
	Array(
		"Филлеры",
		"#",
		Array(),
		Array("INFO"=>"77 материалов"),
		""
	),
	Array(
		"Нити",
		"/pro/threads/articles/",
		Array(),
		Array("INFO"=>"46 материалов"),
		""
	),
	Array(
		"Лазеры",
		"/pro/lasers/articles/",
		Array(),
		Array("INFO"=>"140 материалов"),
		""
	)
);