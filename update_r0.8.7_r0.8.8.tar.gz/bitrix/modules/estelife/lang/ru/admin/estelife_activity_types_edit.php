<?php
$MESS ['ESTELIFE_T_BASE'] = 'Основное';
$MESS ['ESTELIFE_F_NAME'] = 'Название';
$MESS ['ESTELIFE_F_DESRIPTION'] = 'Описание';
$MESS ['ESTELIFE_HEAD_TITLE']='Редактирование типа';