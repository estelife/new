<?php
$MESS ['ESTELIFE_T_BASE']='Основное';
$MESS ['ESTELIFE_T_CALENDAR']='Время';
$MESS ['ESTELIFE_F_NAME']='Название';
$MESS ['ESTELIFE_CREATE_TITLE']='Редактирование секции';
