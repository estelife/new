<?php
$MESS ['ESTELIFE_HEAD_TITLE'] = 'Список квитанций';
$MESS ["ESTELIFE_F_ID"] = 'ID';
$MESS ["ESTELIFE_F_USER"] = 'Имя пользователя';
$MESS ["ESTELIFE_F_USER_ID"] = 'ID пользователя';
$MESS ["ESTELIFE_F_USER_EMAIL"] = 'E-mail пользователя';
$MESS ["ESTELIFE_F_EDUCATION"] = 'Название обучения';
$MESS ["ESTELIFE_F_EDUCATION_ID"] = 'ID обучения';
$MESS ["ESTELIFE_F_PAYMENT_ID"] = 'ID платежа';
$MESS ["ESTELIFE_F_STATUS"] = 'Статус';
$MESS ["ESTELIFE_F_DATE_CREATE"] = 'Дата создания';
$MESS ["ESTELIFE_F_DATE_CHANGE"] = 'Дата изменения';
$MESS ["ESTELIFE_F_AMOUNT"] = 'Сумма';
$MESS ['ESTELIFE_EDIT']='Изменить';