<?php
$MESS ['ESTELIFE_F_ID']='ID';
$MESS ['ESTELIFE_F_NAME']='Название';
$MESS ['ESTELIFE_EDIT_ALT']='Изменить';
$MESS ['ESTELIFE_EDIT']='Изменить';
$MESS ['ESTELIFE_DELETE_ALT']='Удалить';
$MESS ['ESTELIFE_DELETE']='Удалить';
$MESS ['ESTELIFE_CREATE']='Добавить секцию';
$MESS ['ESTELIFE_CONFIRM_DELETE']='Вы действительно хотите удалить эту секцию?';
$MESS ['ESTELIFE_HEAD_TITLE']='Список секций';
$MESS ['ESTELIFE_F_EVENT']='Мероприятие';
$MESS ['ESTELIFE_F_HALLS']='Залы';
