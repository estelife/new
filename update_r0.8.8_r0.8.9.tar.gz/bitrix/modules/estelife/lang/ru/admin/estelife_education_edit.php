<?php
$MESS ['ESTELIFE_CREATE_TITLE']='Добавление онлайн обучения';
$MESS ['ESTELIFE_F_NAME']='Название';
$MESS ['ESTELIFE_F_DATE']='Дата';
$MESS ['ESTELIFE_F_PRICE']='Цена';
$MESS ['ESTELIFE_T_BASE'] = 'Основное';
$MESS ['ESTELIFE_T_BASE_TITLE'] = 'Основные параметры онлайн обучения';

$MESS['NAME_NOT_FILL']='Не указано название';
$MESS['DATE_NOT_FILL']='Не указана дата';
$MESS['PRICE_NOT_FILL']='Не указана цена';
$MESS['ERROR_FIELD_FILL']='Ошибка заполнения';