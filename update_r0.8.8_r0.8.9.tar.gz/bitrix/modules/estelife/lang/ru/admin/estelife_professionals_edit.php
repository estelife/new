<?php
$MESS ['ESTELIFE_T_BASE']='Основное';
$MESS ['ESTELIFE_F_USER_ID']='Пользователь';
$MESS ['ESTELIFE_F_COUNTRY']='Страна';
$MESS ['ESTELIFE_F_CITY']='Город';
$MESS ['ESTELIFE_F_SHORT_DESCRIPTION']='Краткое описание';
$MESS ['ESTELIFE_F_FULL_DESCRIPTION']='Подробное описание';
$MESS ['NOT_COUNTRY']='Страна';
$MESS['NOT_USER'] = 'Пользователь';
$MESS ['NOT_CITY']='Город';
$MESS ['ESTELIFE_HEAD_TITLE']='Редактирование специалиста';

