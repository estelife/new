<?php
$MESS ['ESTELIFE_T_BASE']='Основное';
$MESS ['ESTELIFE_T_CALENDAR']='Время';
$MESS ['ESTELIFE_F_NAME']='Название';
$MESS ['ESTELIFE_CREATE_TITLE']='Редактирование секции';
$MESS ['ESTELIFE_F_EVENT']='Мероприятие';
$MESS ['ESTELIFE_F_HALLS']='Залы';
$MESS ['NAME_NOT_EVENT']='Мероприятие';
