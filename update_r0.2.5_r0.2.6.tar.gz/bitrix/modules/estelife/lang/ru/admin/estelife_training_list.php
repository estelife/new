<?php
$MESS ['ESTELIFE_HEAD_TITLE'] = 'Список обучений';
$MESS ['ESTELIFE_F_FULL_NAME'] = 'Полное название';
$MESS ['ESTELIFE_F_COMPANY_NAME'] = 'Учебный центр';
$MESS ['ESTELIFE_F_COUNTRY'] = 'Страна';
$MESS ['ESTELIFE_F_CITY'] = 'Город';
$MESS ['ESTELIFE_F_ID'] = 'ID';
$MESS ['ESTELIFE_CREATE'] = 'Создать обучение';
$MESS ['ESTELIFE_CREATE_TITLE'] = 'Отобразиться форма для создания обучения';

$MESS ['ESTELIFE_EDIT_ALT']='Редактирование';
$MESS ['ESTELIFE_DELETE_ALT']='Удаление';
$MESS ['ESTELIFE_CONFIRM_DELETE']='Вы дейсвтительно хотите удалить эту запись и связанные с ней данные?';
$MESS ['ESTELIFE_EDIT']='Изменить';
$MESS ['ESTELIFE_DELETE']='Удалить';
$MESS ['ESTELIFE_NOT_IMPORTANT']='Не важно';