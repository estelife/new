<?php
$MESS["PARAMS_ERROR"] = "Ошибка в задании параметров";
?>