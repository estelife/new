<?php
$MESS ['ESTELIFE_HEAD_TITLE'] = 'Список комментариев';
$MESS ['ESTELIFE_F_NAME'] = 'ФИО';
$MESS ['ESTELIFE_F_USER_ID'] = 'Пользователь';
$MESS ['ESTELIFE_F_ACTIVE'] = 'Активность';
$MESS ['ESTELIFE_F_MODERATE'] = 'Модерация';
$MESS ['ESTELIFE_F_ID'] = 'ID';
$MESS ['ESTELIFE_F_TEXT'] = 'Текст комментария';
$MESS ['ESTELIFE_F_DATE_CREATE'] = 'Дата добавления';

$MESS ['ESTELIFE_CREATE'] = 'Создать обучение';
$MESS ['ESTELIFE_CREATE_TITLE'] = 'Отобразиться форма для создания обучения';




$MESS ['ESTELIFE_EDIT_ALT']='Редактирование';
$MESS ['ESTELIFE_DELETE_ALT']='Удаление';
$MESS ['ESTELIFE_MODERATE_ALT']='Модерация';
$MESS ['ESTELIFE_ACTIVE_ALT']='Активировать';
$MESS ['ESTELIFE_CONFIRM_DELETE']='Вы действительно хотите удалить эту запись и связанные с ней данные?';
$MESS ['ESTELIFE_CONFIRM_ACTIVE']='Вы действительно хотите активировать комментарий?';
$MESS ['ESTELIFE_CONFIRM_DEACTIVE']='Вы действительно хотите заблокировать комментарий?';
$MESS ['ESTELIFE_MODERATE']='Разрешить';
$MESS ['ESTELIFE_ACTIVE']='Активировать';
$MESS ['ESTELIFE_DEACTIVE']='Заблокировать';
$MESS ['ESTELIFE_DELETE']='Удалить';
$MESS ['ESTELIFE_NOT_IMPORTANT']='Не важно';