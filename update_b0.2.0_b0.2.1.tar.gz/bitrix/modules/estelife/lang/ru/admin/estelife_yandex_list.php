<?php
$MESS ['ESTELIFE_F_ID']='ID';
$MESS ['ESTELIFE_F_BLOCK']='ID Блока';
$MESS ['ESTELIFE_F_NAME']='Название';
$MESS ['ESTELIFE_F_SEND']='Статус';
$MESS ['ESTELIFE_ACTION_SEND'] = 'Отправить';
$MESS ['FORM_SEND_L'] = 'Отправить';
$MESS ['ESTELIFE_CONFIRM_SEND'] = 'Вы действительно хотите отправить?';
