<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetPageProperty("title", "Защита контента");
$APPLICATION->SetPageProperty("description", "Защита контента");
$APPLICATION->SetPageProperty("keywords", "Estelife, Защита контента");
?>
<div class="content">
	sdsfdsf
</div>
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>