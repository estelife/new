<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetPageProperty("title", "О проекте");
$APPLICATION->SetPageProperty("description", "О проекте");
$APPLICATION->SetPageProperty("keywords", "Estelife, О проекте");
?>
<div class="content">
	О проекте
</div>
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>