<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetPageProperty("title", "Связь с редакцией");
$APPLICATION->SetPageProperty("description", "Связь с редакцией");
$APPLICATION->SetPageProperty("keywords", "Estelife, Связь с редакцией");
?>
<div class="content">
	Связь с редакцией
</div>
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>