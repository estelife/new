<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetPageProperty("title", "Размещение рекламы");
$APPLICATION->SetPageProperty("description", "Размещение рекламы");
$APPLICATION->SetPageProperty("keywords", "Estelife, Размещение рекламы");
?>
<div class="content">
	Размещение рекламы
</div>
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>