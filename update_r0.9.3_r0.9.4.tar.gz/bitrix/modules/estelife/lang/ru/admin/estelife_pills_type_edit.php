<?php
$MESS ['ESTELIFE_CREATE_TITLE'] = 'Добавление типа';
$MESS ['ESTELIFE_F_TITLE'] = 'Название';
$MESS ['ESTELIFE_F_TYPE'] = 'Тип';

$MESS ['ESTELIFE_T_BASE'] = 'Добавление типа';
$MESS ['ESTELIFE_F_TYPE_SELECT'] = 'Выберите тип';
$MESS['NAME_NOT_FILL']='Не указано название';
$MESS['TYPE_NOT_FILL']='Не указан тип';

