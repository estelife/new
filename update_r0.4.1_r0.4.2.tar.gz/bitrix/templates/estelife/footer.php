	</div>
	<div class="footer">
		<div class="footer-in">
			<div class="content">
<!--				<ul class="menu cols">-->
<!--					<li><a href="#">О проекте</a></li>-->
<!--					<li><a href="#">Связь с редакцией</a></li>-->
<!--					<li><a href="#">Размещение рекламы</a></li>-->
<!--					<li><a href="#">Защита контента</a></li>-->
<!--				</ul>-->
				<div class="copy">
					2011-2013 &copy; ООО &laquo;Эстелайф&raquo;. Estelife.ru. Портал эстетической медицины
					<span><b>18</b>+</span>
					<div class="cols col2 social">
						<a href="http://vk.com/estelife_ru" class="vk" target="_blank">ВКонтакте</a>
						<a href="https://www.facebook.com/EsteLife.RU" class="fb" target="_blank">Facebook</a>
						<a href="http://www.youtube.com/esteliferu" class="yt" target="_blank">Youtube</a>
						<a href="https://plus.google.com/u/0/b/106608290098923557575/" class="gp" target="_blank">Google+</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--	<img src="/el.png" class="home-img" />-->
</body>
</html>
