<?php
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true)
	die();

bitrix\ERESULT::$DATA['EXPERTS']=array(
	'TITLE'=>$arParams['TITLE'],
	'iblock'=>$arResult['iblock']
);