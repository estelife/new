<?php
$MESS ['ESTELIFE_CREATE_TITLE'] = 'Добавление аппарата';
$MESS ['ESTELIFE_F_TITLE'] = 'Название';
$MESS ['ESTELIFE_F_TRANSLIT'] = 'Транслитерация';
$MESS ['ESTELIFE_F_LOGO'] = 'Изображение аппарата';
$MESS ['ESTELIFE_F_COMPANY'] = 'Производитель';
$MESS ['ESTELIFE_F_TYPE'] = 'Вид аппарата';
$MESS ['ESTELIFE_F_FORMAT'] = 'Тип аппарата';
$MESS ['ESTELIFE_F_PREVIEW'] = 'Краткое описание';
$MESS ['ESTELIFE_F_DETAIL'] = 'Подробное описание';
$MESS ['ESTELIFE_F_ACTION'] = 'Действие';
$MESS ['ESTELIFE_F_EVIDENCE'] = 'Показания';
$MESS ['ESTELIFE_F_CONTRA'] = 'Противопоказания';
$MESS ['ESTELIFE_F_SPECS'] = 'Технические характеристики';
$MESS ['ESTELIFE_F_FUNC'] = 'Функции';
$MESS ['ESTELIFE_F_REGISTRATION'] = 'Регистрация';
$MESS ['ESTELIFE_F_ADVANTAGES'] = 'Преимущества';
$MESS ['ESTELIFE_F_PROCEDURE'] = 'Курс процедур';
$MESS ['ESTELIFE_F_SECURITY'] = 'Безопасность';
$MESS ['ESTELIFE_F_PROTOCOL'] = 'Протокол процедуры';
$MESS ['ESTELIFE_F_UNDESIRED'] = 'Побочные эффекты';
$MESS ['ESTELIFE_F_EQUIPMENT'] = 'Комплектация';

$MESS ['ESTELIFE_F_TYPE_SELECT'] = 'Выберите тип аппарата';
$MESS ['ESTELIFE_T_BASE'] = 'Добавление аппарата';
$MESS ['ESTELIFE_T_GALLERY'] = 'Фото до/после';
$MESS ['ESTELIFE_T_CERTIFICATION'] = 'Сертификаты';
$MESS ['ESTELIFE_T_FITTING'] = 'Аксессуары';
$MESS['NAME_NOT_FILL']='Не указано название';
$MESS['FORMAT_NOT_FILL']='Не указан тип аппарата';
$MESS['COMPANY_NOT_FILL']='Не указан производитель';
$MESS['TYPE_NOT_FILL']='Не указан тип аппарата';
$MESS['COMPANY_ERROR']='Производитель не найден';

