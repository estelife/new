<?php
namespace core\utils\forms;

/**
 * Класс для создания токена
 * @file class.VToken.php
 * @version 0.1
 */
class VToken extends VField {

	public function __toString(){
		return '';
	}
}