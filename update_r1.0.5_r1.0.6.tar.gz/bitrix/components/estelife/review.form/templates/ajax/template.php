<?php
echo json_encode(array(
	'reviews' => $arResult
));