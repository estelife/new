<?php
namespace lists\adapters;

/**
 * Вероятно я забыл оставить описание файла. Обратитесь на мыло за уточнениями.
 * @author Dmitriy Konev <dnkonev@yandex.ru>
 * @since 03.12.13
 */
interface VAdapter {
	public function prepare(&$arData);
}