<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>
<div class="content">
	<img src="/bitrix/templates/estelife/images/404.jpg" alt="Запрашиваемая вами страница не найдена" title="Запрашиваемая вами страница не найдена" class="p404" />
</div>