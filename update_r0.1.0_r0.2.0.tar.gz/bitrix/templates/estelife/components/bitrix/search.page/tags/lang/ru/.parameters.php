<?
$MESS["SEARCH_FONT_MAX"] = "Максимальный размер шрифта (px)";
$MESS["SEARCH_FONT_MIN"] = "Минимальный размер шрифта (px)";
$MESS["SEARCH_COLOR_OLD"] = "Цвет раннего тега (пример: \"FEFEFE\")";
$MESS["SEARCH_COLOR_NEW"] = "Цвет позднего тега (пример: \"C0C0C0\")";
$MESS["SEARCH_CNT"] = "По популярности";
$MESS["SEARCH_COLOR_TYPE"] = "Плавное изменение цвета";
$MESS["SEARCH_NAME"] = "По имени";
$MESS["SEARCH_PAGE_ELEMENTS"] = "Количество тегов";
$MESS["SEARCH_PERIOD"] = "Период выборки тегов (дней)";
$MESS["SEARCH_PERIOD_NEW_TAGS"] = "Период, в течение которого считать тег новым (дней)";
$MESS["SEARCH_TAGS_INHERIT"] = "Сужать область поиска";
$MESS["SEARCH_WIDTH"] = "Ширина облака тегов (пример: \"100%\" или \"100px\", \"100pt\", \"100in\")";
$MESS["SEARCH_URL_SEARCH"] = "Путь к странице поиска (от корня сайта)";
$MESS["SEARCH_SHOW_CHAIN"] = "Показывать цепочку навигации";
$MESS["SEARCH_SORT"] = "Сортировка тегов";
$MESS["TP_BSP_USE_SUGGEST"] = "Показывать подсказку с поисковыми фразами";
$MESS["TP_BSP_SHOW_RATING"] = "Включить рейтинг";
$MESS["TP_BSP_SHOW_RATING_CONFIG"] = "по умолчанию";
$MESS["TP_BSP_RATING_TYPE"] = "Вид кнопок рейтинга";
$MESS["TP_BSP_RATING_TYPE_CONFIG"] = "по умолчанию";
$MESS["TP_BSP_RATING_TYPE_STANDART_TEXT"] = "Нравится / Не нравится (текстовый)";
$MESS["TP_BSP_RATING_TYPE_STANDART_GRAPHIC"] = "Нравится / Не нравится (графический)";
$MESS["TP_BSP_RATING_TYPE_LIKE_TEXT"] = "Мне нравится (текстовый)";
$MESS["TP_BSP_RATING_TYPE_LIKE_GRAPHIC"] = "Мне нравится (графический)";
$MESS["TP_BSP_PATH_TO_USER_PROFILE"] = "Шаблон пути к профилю пользователя";
?>