<?php
$MESS ['ESTELIFE_F_USER_NAME'] = 'Имя';
$MESS ['ESTELIFE_F_USER_LAST_NAME'] = 'Фамилия';
$MESS ['ESTELIFE_F_DATE_VISIT'] = 'Дата визита';
$MESS ['ESTELIFE_F_CLINIC'] = 'Клиника';
$MESS ['ESTELIFE_F_PROBLEM'] = 'Проблема';
$MESS ['ESTELIFE_F_SPECIALIST'] = 'Специалист';
$MESS ['ESTELIFE_F_POSITIVE'] = 'Понравилось';
$MESS ['ESTELIFE_F_NEGATIVE'] = 'Не понравилось';
$MESS ['ESTELIFE_F_ACTIVE'] = 'Активность';
$MESS ['ESTELIFE_F_SELECT_PROBLEM'] = 'Выберите проблему';
$MESS ['ESTELIFE_T_BASE'] = 'Отзыв';

