<?php
$MESS ['ESTELIFE_T_BASE'] = 'Основное';
$MESS ['ESTELIFE_F_TITLE'] = 'Название';
$MESS ['TITLE_IS_EMPTY']='Название не указано';