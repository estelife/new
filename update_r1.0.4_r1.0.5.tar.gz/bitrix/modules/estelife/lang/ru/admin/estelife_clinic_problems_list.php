<? $MESS ['ESTELIFE_F_ID'] = 'ID';
   $MESS ['ESTELIFE_F_TITLE'] = 'Название';
   $MESS ['ESTELIFE_CREATE'] = 'Добавить проблему';
   $MESS ['ESTELIFE_CREATE_TITLE'] = 'Добавить проблему';
   $MESS ['ESTELIFE_EDIT_ALT'] = 'Изменить';
   $MESS ['ESTELIFE_EDIT'] = 'Изменить';
   $MESS ['ESTELIFE_DELETE'] = 'Удалить';
   $MESS ['ESTELIFE_DELETE_ALT'] = 'Удалить';
   $MESS ['ESTELIFE_CONFIRM_DELETE'] = 'Вы действительно хотите удалить эту запись?';


