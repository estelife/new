<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<form action="<?=$arResult["FORM_ACTION"]?>" name="search">
	<input type="text" class="text" name="q" placeholder="Поиск по сайту" />
	<input type="submit" class="submit" name="s" value="Найти" />
</form>