<?
$MESS["T_IBLOCK_DESC_NEWS_DATE"] = "Display element date";
$MESS["T_IBLOCK_DESC_NEWS_PICTURE"] = "Display element preview picture";
$MESS["T_IBLOCK_DESC_NEWS_TEXT"] = "Display element preview text";
$MESS["SEARCH_PAGE_ELEMENTS"] = "Number of tags";
$MESS["SEARCH_FONT_MAX"] = "Largest font size (px)";
$MESS["SEARCH_FONT_MIN"] = "Smallest font size (px)";
$MESS["SEARCH_COLOR_OLD"] = "Latest tag color (ex. \"FEFEFE\")";
$MESS["SEARCH_COLOR_NEW"] = "Earliest tag color (ex. \"C0C0C0\")";
$MESS["SEARCH_PERIOD_NEW_TAGS"] = "Consider tag new during (days)";
$MESS["SEARCH_WIDTH"] = "Tag cloud width (ex. \"100%\", \"100px\", \"100pt\" or \"100in\")";
$MESS["TP_CBIV_DISPLAY_AS_RATING"] = "Show in rating ";
$MESS["TP_CBIV_AVERAGE"] = "Average value";
$MESS["TP_CBIV_RATING"] = "Rating value";
$MESS["T_IBLOCK_DESC_NEWS_USE_SHARE"] = "Show Social Network Bookmarks Bar";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_HIDE"] = "Hide Social Network Bookmarks Bar By Default";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_TEMPLATE"] = "Social Network Bookmarks Template";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SYSTEM"] = "Use Social Networks And Bookmarks";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SHORTEN_URL_LOGIN"] = "bit.ly Login";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SHORTEN_URL_KEY"] = "bit.ly Key";
?>