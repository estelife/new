<div class="yvoire-sidebar">
	<a href="/yvoire/yvoire-hydro/"><img src="/yvoire/img/sidebar-hydro.jpg" class="yvoire" /></a>
	<a href="/yvoire/yvoire-classic/"><img src="/yvoire/img/sidebar-classic.jpg" class="yvoire" /></a>
	<a href="/yvoire/yvoire-volume/"><img src="/yvoire/img/sidebar-volume.jpg" class="yvoire" /></a>
	<img src="/yvoire/img/sidebar-innovation.jpg"  class="yvoire" />
</div>