<?php
$MESS ['ESTELIFE_CREATE_TITLE'] = 'Добавление вида услуги';
$MESS ['ESTELIFE_F_TITLE'] = 'Название';
$MESS ['ESTELIFE_F_SPEC'] = 'Специализация';
$MESS ['ESTELIFE_NOT_IMPORTANT'] = 'Не важно';
$MESS ['ESTELIFE_T_BASE'] = 'Основное';
$MESS ['ESTELIFE_T_BASE_TITLE'] = 'Основные параметры вида услуги';

$MESS['NAME_NOT_FILL']='Не указано название';
$MESS['SPEC_NOT_FILL']='Не указана специализация';
$MESS['ERROR_FIELD_FILL']='Ошибка заполнения';