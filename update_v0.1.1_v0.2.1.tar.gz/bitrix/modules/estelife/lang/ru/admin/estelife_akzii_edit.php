<?php
$MESS['NAME_NOT_FILL']='Не указано название';
$MESS['DETAIL_TEXT_NOT_FILL']='Детальный текст не указан';
$MESS ['ESTELIFE_CREATE_TITLE'] = 'Добавление акции';
$MESS ['ESTELIFE_F_TITLE'] = 'Название';
$MESS ['ESTELIFE_F_CLINIC'] = 'Клиника';
$MESS ['ESTELIFE_F_ACTIVE'] = 'Активность';
$MESS ['ESTELIFE_F_OLD_PRICE']='Старая цена';
$MESS ['ESTELIFE_F_NEW_PRICE']='Новая цена';
$MESS ['ESTELIFE_F_START_DATE']='Дата начала';
$MESS ['ESTELIFE_F_END_DATE']='Дата завершения';
$MESS ['ESTELIFE_T_BASE'] = 'Основное';
$MESS ['ESTELIFE_T_BASE_TITLE'] = 'Основные параметры акции';
$MESS ['ESTELIFE_T_PREVIEW_TEXT'] = 'Кратко';
$MESS ['ESTELIFE_T_DETAIL_TEXT'] = 'Подробно';
$MESS ['ESTELIFE_T_GALLERIES']='Галлерея';
$MESS ['ESTELIFE_T_NOTE']='Цены';
$MESS ['ESTELIFE_T_BASE_PRICE']='Базовые цены';
$MESS ['ESTELIFE_T_PROCEDURE_PRICE']='Цены на процедуры';
$MESS ['ESTELIFE_F_SALE']='Скидка';

$MESS ['ESTELIFE_F_PROCEDURE']='Процедура';
$MESS ['ESTELIFE_F_TYPE']='Тип услуг';
$MESS ['ESTELIFE_F_SELECT_TYPE']='Выберите тип услуг';

$MESS ['ESTELIFE_T_PHOTO'] = 'Фото';
$MESS ['ESTELIFE_F_SMALL_PHOTO']='Маленькая фотка';
$MESS ['ESTELIFE_F_BIG_PHOTO']='Большая фотка';
$MESS ['ESTELIFE_F_VIEW_TYPE']='Тип отображения';
$MESS ['ESTELIFE_F_MORE_INFORMATION']='Подробная информация и цены (ссылка)';