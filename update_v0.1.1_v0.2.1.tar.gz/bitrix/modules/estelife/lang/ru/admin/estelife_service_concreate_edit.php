<?php
$MESS ['ESTELIFE_CREATE_TITLE'] = 'Добавление типа услуги';
$MESS ['ESTELIFE_F_TITLE'] = 'Название';
$MESS ['ESTELIFE_F_SPEC'] = 'Специализация';
$MESS ['ESTELIFE_F_SERVICE'] = 'Тип услуги';
$MESS ['ESTELIFE_F_METHOD']='Методика';
$MESS ['ESTELIFE_NOT_IMPORTANT'] = 'Не важно';
$MESS ['ESTELIFE_T_BASE'] = 'Основное';
$MESS ['ESTELIFE_T_BASE_TITLE'] = 'Основные параметры типа услуги';

$MESS['NAME_NOT_FILL']='Не указано название';
$MESS['SPEC_NOT_FILL']='Не указана специализация';
$MESS['SERVICE_NOT_FILL']='Не указан тип услуги';
$MESS['ERROR_FIELD_FILL']='Ошибка заполнения';