<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/estelife/admin/estelife_entry_list.php");?>
